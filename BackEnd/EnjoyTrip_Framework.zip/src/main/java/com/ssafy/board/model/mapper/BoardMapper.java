package com.ssafy.board.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.board.model.BoardDto;

@Mapper
public interface BoardMapper {

	int writeArticle(BoardDto boardDto);
	List<BoardDto> listArticle();
	BoardDto viewArticle(int articleNo);
	void updateHit(int articleNo);
	int modifyArticle(BoardDto boardDto); // 글 수정 
	int deleteArticle(int articleNo); // 글 삭제
	List<BoardDto> searchArticle(String option,String search); // 검색 
}
