package com.ssafy.board.model.service;

import java.util.List;

import com.ssafy.board.model.BoardDto;

/** 게시판 기능을 위한 서비스 기능 선언 */
public interface BoardService {
	
	int writeArticle(BoardDto boardDto);
	List<BoardDto> listArticle();
	BoardDto viewArticle(int articleNo);
	void updateHit(int articleNo);

	int modifyArticle(BoardDto boardDto); // 글 수정 
	int deleteArticle(int articleNo); // 글 삭제
	List<BoardDto> searchArticle(String option,String search); // 검색 
	
}
