package com.ssafy.board.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.board.model.BoardDto;
import com.ssafy.board.model.service.BoardService;
import com.ssafy.board.model.service.BoardServiceImpl;

@Controller
@RequestMapping("/board")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private final Logger logger = LoggerFactory.getLogger(BoardController.class);

	BoardService boardService;

	public BoardController(BoardService boardService) {
		super();
		this.boardService = boardService;
	}

	// 게시글 등록화면 요청 서비스
	@GetMapping("/register")
	public String registerForm(HttpSession session) {
		return "/board/write";
	}

	@PostMapping("/register")
	public String writeArticle(@RequestParam Map<String, String> map) throws SQLException {
		BoardDto boardDto = new BoardDto();
		boardDto.setUser_id(map.get("userid"));
		boardDto.setSubject(map.get("subject"));
		boardDto.setContent(map.get("content"));

		boardService.writeArticle(boardDto);
		// TODO 성공여부 1, 0 추가해줄거면 추가

		return "redirect:list";
	}

	@GetMapping("/list")
	public ModelAndView listArticle() throws SQLException {
		ModelAndView mav = new ModelAndView();

		List<BoardDto> list = null;

		list = boardService.listArticle();

		mav.addObject("list", list);
		mav.setViewName("/board/list");

		return mav;
	}

	@GetMapping("/view")
	public ModelAndView viewArticle(String articleNo) throws SQLException {

		ModelAndView mav = new ModelAndView();
		System.out.println("view 들어옴 + articleNo " + articleNo);
		boardService.updateHit(Integer.parseInt(articleNo));

		BoardDto boardDto = boardService.viewArticle(Integer.parseInt(articleNo));

		mav.addObject("boardDto", boardDto);
		mav.setViewName("/board/view");

		return mav;
	}

	@GetMapping("/serch")
	public ModelAndView search(@RequestParam Map<String, String> map) throws SQLException {

		ModelAndView mav = new ModelAndView();
		// 1. 검색 옵션 및 검색어
		String option = map.get("option");
		String search = map.get("search");
		List<BoardDto> list = null;

		// 2. 전체 조회 / 그 외 나누어서 DB 에서 select
		if (option.equals("all")) {
			list = boardService.listArticle();
		} // 전체 조회 -> 전체 리스트 보여주면 됨

		else {
			list = boardService.searchArticle(option, search);
			if (list.size() == 0) {
				list = boardService.listArticle();
			} // 조회 결과가 없다면 전체 리스트 보여주게
		}

		mav.addObject("list", list);
		mav.setViewName("/board/list");

		return mav;
	}

	@GetMapping("/modify")
	public ModelAndView modifyView(String articleNo) throws SQLException {

		ModelAndView mav = new ModelAndView();

		BoardDto boardDto = boardService.viewArticle(Integer.parseInt(articleNo));

		mav.addObject("boardDto", boardDto);
		mav.setViewName("/board/modify");

		return mav;
	}

	@PostMapping("/modify")
	public String modify(BoardDto boardDto) throws SQLException {

		System.out.println("modify 들어옴. 수정 된 DTO :" + boardDto );
		boardService.modifyArticle(boardDto);

		return "redirect:/board/list";

	}

	@PostMapping("/delete")
	public String delete(String articleNo) throws SQLException {

		boardService.deleteArticle(Integer.parseInt(articleNo));

		return "redirect:/board/list";
	}
}
