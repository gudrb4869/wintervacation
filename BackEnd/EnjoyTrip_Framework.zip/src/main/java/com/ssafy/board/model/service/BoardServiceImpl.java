package com.ssafy.board.model.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.board.model.BoardDto;
import com.ssafy.board.model.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {

	BoardMapper boardMapper;
	
	public BoardServiceImpl(BoardMapper boardMapper) {
		super();
		this.boardMapper = boardMapper;
	}
	
	@Override
	public int writeArticle(BoardDto boardDto) {
		return boardMapper.writeArticle(boardDto);
	}

	@Override
	public List<BoardDto> listArticle() {
		return boardMapper.listArticle();
	}

	@Override
	public BoardDto viewArticle(int articleNo) {
		return boardMapper.viewArticle(articleNo);
	}

	@Override
	public int modifyArticle(BoardDto boardDto) {
		return boardMapper.modifyArticle(boardDto);
	}

	@Override
	public int deleteArticle(int articleNo) {
		return boardMapper.deleteArticle(articleNo);
	}

	@Override
	public List<BoardDto> searchArticle(String option, String search) {
		return boardMapper.searchArticle(option, search);
	}

	@Override
	public void updateHit(int articleNo) {
		boardMapper.updateHit(articleNo);
		
	}

}
